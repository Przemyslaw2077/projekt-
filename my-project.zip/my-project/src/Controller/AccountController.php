<?php

namespace App\Controller;

use App\Entity\Order;
use App\Entity\OrderItem;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AccountController extends AbstractController
{
    #[Route('/account', name: 'account_stats')]
    public function stats(EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_USER');

        $user = $this->getUser();

        if (!$user instanceof User) {
            throw $this->createAccessDeniedException();
        }

        $userId = $user->getId();

        /* =========================
           🧾 ZAMÓWIENIA
        ========================= */
        $orders = $em->getRepository(Order::class)
            ->findBy(['user' => $user], ['createdAt' => 'DESC']);

        $ordersCount = count($orders);

        /* =========================
           💰 ŁĄCZNA KWOTA
        ========================= */
        $totalSpent = 0.0;

        foreach ($orders as $order) {
            foreach ($order->getItems() as $item) {
                $totalSpent += $item->getPrice() * $item->getQuantity();
            }
        }

        /* =========================
           📦 OSTATNIE ZAMÓWIENIE
        ========================= */
        $lastOrder = $orders[0] ?? null;

        /* =========================
           📈 WYKRES – WYDATKI PER DZIEŃ
        ========================= */
        $sql = "
            SELECT 
                DATE(o.created_at) AS day,
                SUM(oi.price * oi.quantity) AS total
            FROM order_items oi
            JOIN orders o ON o.id = oi.order_id
            WHERE o.user_id = :user
            GROUP BY day
            ORDER BY day ASC
        ";

        $conn = $em->getConnection();

        $result = $conn->executeQuery(
            $sql,
            ['user' => $userId]
        );

        $rawChartData = $result->fetchAllAssociative();

        $chartLabels = [];
        $chartValues = [];

        foreach ($rawChartData as $row) {
            $chartLabels[] = $row['day'];         
            $chartValues[] = (float) $row['total'];
        }

        /* =========================
           ⭐ TOP PRODUKT
        ========================= */
       $qb = $em->createQueryBuilder();

$qb->select('p.name AS name, SUM(i.quantity) AS qty')
    ->from(OrderItem::class, 'i')
    ->join('i.product', 'p')
    ->join('i.order', 'o')
    ->where('o.user = :user')
    ->setParameter('user', $user)
    ->groupBy('p.id')
    ->orderBy('qty', 'DESC')
    ->setMaxResults(5);

$topProducts = $qb->getQuery()->getResult();

return $this->render('account/stats.html.twig', [
    'ordersCount'  => $ordersCount,
    'totalSpent'   => $totalSpent,
    'lastOrder'    => $lastOrder,
    'chartLabels'  => $chartLabels,
    'chartValues'  => $chartValues,
    'topProducts'  => $topProducts, 
]);

    }
}
