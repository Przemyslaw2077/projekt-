<?php

namespace App\Controller;

use App\Entity\Product;
use App\Entity\Category;
use App\Repository\ProductRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{
    #[Route('/produkty', name: 'products')]
    public function index(ProductRepository $repo): Response
    {
        return $this->render('products.html.twig', [
            'products' => $repo->findAll()
        ]);
    }

    #[Route('/admin/products', name: 'admin_products')]
    public function adminList(ProductRepository $repo): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

    

        return $this->render('admin/products/admin_list.html.twig', [
            'products' => $repo->findAll()
        ]);
    }

    #[Route('/admin/products/add', name: 'admin_products_add')]
    public function add(Request $request, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if ($request->isMethod('POST')) {
            $product = new Product();
            $product->setName($request->request->get('name'));
            $product->setDescription($request->request->get('description'));
            $product->setStock((int)$request->request->get('stock'));
            $product->setPrice($request->request->get('price'));

            $categoryId = (int)$request->request->get('category');
            $category = $em->getRepository(Category::class)->find($categoryId);
            $product->setCategory($category);

            $em->persist($product);
            $em->flush();

            return $this->redirectToRoute('admin_products');
        }

        $categories = $em->getRepository(Category::class)->findAll();

        return $this->render('admin/products/admin_add.html.twig', [
            'categories' => $categories
        ]);
    }

    #[Route('/admin/products/edit/{id}', name: 'admin_products_edit')]
    public function edit(Product $product, Request $request, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if ($request->isMethod('POST')) {
            $product->setName($request->request->get('name'));
            $product->setDescription($request->request->get('description'));
            $product->setStock((int)$request->request->get('stock'));
            $product->setPrice($request->request->get('price'));

            $categoryId = (int)$request->request->get('category');
            $category = $em->getRepository(Category::class)->find($categoryId);
            $product->setCategory($category);

            $em->flush();

            return $this->redirectToRoute('admin_products');
        }

        $categories = $em->getRepository(Category::class)->findAll();

        return $this->render('admin/products/admin_edit.html.twig', [
            'product' => $product,
            'categories' => $categories
        ]);
    }

    #[Route('/admin/products/delete/{id}', name: 'admin_products_delete')]
    public function delete(Product $product, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        $em->remove($product);
        $em->flush();

        return $this->redirectToRoute('admin_products');
    }
}
