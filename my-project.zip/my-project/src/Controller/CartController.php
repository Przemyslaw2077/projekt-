<?php

namespace App\Controller;

use App\Entity\Cart;
use App\Entity\Product;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CartController extends AbstractController
{
    // ✅ dodawanie do koszyka (to już masz, ale tu jest wersja kompletna)
    public function add(Product $product, EntityManagerInterface $em): RedirectResponse
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        if ($product->getStock() <= 0) {
            $this->addFlash('error', 'Produkt niedostępny.');
            return $this->redirectToRoute('products');
        }

        $cart = $em->getRepository(Cart::class)->findOneBy([
            'user' => $user,
            'product' => $product
        ]);

        if ($cart) {
            if ($cart->getQuantity() + 1 > $product->getStock()) {
                $this->addFlash('error', 'Brak większej ilości na stanie.');
                return $this->redirectToRoute('products');
            }
            $cart->setQuantity($cart->getQuantity() + 1);
        } else {
            $cart = new Cart();
            $cart->setUser($user);
            $cart->setProduct($product);
            $cart->setQuantity(1);
            $em->persist($cart);
        }

        $em->flush();
        $this->addFlash('success', 'Dodano do koszyka.');

        return $this->redirectToRoute('cart_view');
    }

    // ✅ widok koszyka
    public function view(EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        $items = $em->getRepository(Cart::class)->findBy(['user' => $user]);

        $total = 0.0;
        foreach ($items as $item) {
            $total += (float)$item->getProduct()->getPrice() * $item->getQuantity();
        }

        return $this->render('cart/index.html.twig', [
            'items' => $items,
            'total' => $total,
        ]);
    }

    // ✅ zmiana ilości (POST)
    public function update(int $id, Request $request, EntityManagerInterface $em): RedirectResponse
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        /** @var Cart|null $cart */
        $cart = $em->getRepository(Cart::class)->find($id);

        if (!$cart || $cart->getUser() !== $user) {
            $this->addFlash('error', 'Nie znaleziono pozycji koszyka.');
            return $this->redirectToRoute('cart_view');
        }

        $qty = (int)$request->request->get('quantity', 1);
        if ($qty < 1) {
            $qty = 1;
        }

        $product = $cart->getProduct();
        if ($qty > $product->getStock()) {
            $this->addFlash('error', 'Brak tyle sztuk na stanie.');
            return $this->redirectToRoute('cart_view');
        }

        $cart->setQuantity($qty);
        $em->flush();

        $this->addFlash('success', 'Zmieniono ilość.');
        return $this->redirectToRoute('cart_view');
    }

    // ✅ usuwanie pozycji
    public function remove(int $id, EntityManagerInterface $em): RedirectResponse
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        /** @var Cart|null $cart */
        $cart = $em->getRepository(Cart::class)->find($id);

        if (!$cart || $cart->getUser() !== $user) {
            $this->addFlash('error', 'Nie znaleziono pozycji koszyka.');
            return $this->redirectToRoute('cart_view');
        }

        $em->remove($cart);
        $em->flush();

        $this->addFlash('success', 'Usunięto produkt z koszyka.');
        return $this->redirectToRoute('cart_view');
    }
}
