<?php

namespace App\Controller;

use App\Entity\Category;
use App\Repository\CategoryRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CategoryController extends AbstractController
{

    #[Route('/admin/categories', name: 'admin_categories')]
    public function index(CategoryRepository $repo): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        return $this->render('admin/categories/admin_list.html.twig', [
            'categories' => $repo->findAll()
        ]);
    }


    #[Route('/admin/categories/add', name: 'admin_categories_add')]
    public function add(Request $request, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if ($request->isMethod('POST')) {
            $category = new Category();
            $category->setName($request->request->get('name'));

            $em->persist($category);
            $em->flush();

            return $this->redirectToRoute('admin_categories');
        }

        return $this->render('admin/categories/admin_add.html.twig');
    }


    #[Route('/admin/categories/edit/{id}', name: 'admin_categories_edit')]
    public function edit(Category $category, Request $request, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if ($request->isMethod('POST')) {
            $category->setName($request->request->get('name'));
            $em->flush();

            return $this->redirectToRoute('admin_categories');
        }

        return $this->render('admin/categories/admin_edit.html.twig', [
            'category' => $category
        ]);
    }


    #[Route('/admin/categories/delete/{id}', name: 'admin_categories_delete')]
    public function delete(Category $category, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if (count($category->getProducts()) > 0) {
            $this->addFlash('error', 'Nie można usunąć kategorii, ponieważ zawiera produkty.');
            return $this->redirectToRoute('admin_categories');
        }

        $em->remove($category);
        $em->flush();

        return $this->redirectToRoute('admin_categories');
    }
}
