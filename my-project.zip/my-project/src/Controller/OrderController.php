<?php

namespace App\Controller;

use App\Entity\Order;
use App\Entity\OrderItem;
use App\Entity\Cart;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;

class OrderController extends AbstractController
{
    /**
     * Złożenie zamówienia
     */
    public function checkout(EntityManagerInterface $em): RedirectResponse
    {
        $this->denyAccessUnlessGranted('ROLE_USER');
        $user = $this->getUser();

        // 1️⃣ Pobierz koszyk użytkownika
        $cartItems = $em->getRepository(Cart::class)
            ->findBy(['user' => $user]);

        if (!$cartItems) {
            $this->addFlash('error', 'Koszyk jest pusty.');
            return $this->redirectToRoute('cart_view');
        }

        // 2️⃣ Utwórz zamówienie
        $order = new Order();
        $order->setUser($user);
        $order->setStatus('nowe');
        $em->persist($order);

        // 3️⃣ Przenieś produkty z koszyka do order_items
        foreach ($cartItems as $cart) {
            $product = $cart->getProduct();

            // ❗ Walidacja stanu magazynu
            if ($product->getStock() < $cart->getQuantity()) {
                $this->addFlash(
                    'error',
                    'Brak wystarczającej ilości produktu: ' . $product->getName()
                );
                return $this->redirectToRoute('cart_view');
            }

            // ➜ order_items
            $item = new OrderItem();
            $item->setOrder($order);
            $item->setProduct($product);
            $item->setQuantity($cart->getQuantity());
            $item->setPrice($product->getPrice());
            $em->persist($item);

            // 🔥 Zmniejszenie magazynu
            $product->setStock(
                $product->getStock() - $cart->getQuantity()
            );

            // 🧹 Usuń z koszyka
            $em->remove($cart);
        }

        // 4️⃣ Zapis do bazy
        $em->flush();

        // 5️⃣ Komunikat + powrót do koszyka
        $this->addFlash('success', 'Zamówienie zostało złożone pomyślnie!');
        return $this->redirectToRoute('cart_view');
    }

    /**
     * Historia zamówień użytkownika
     */
    public function history(Request $request, EntityManagerInterface $em): Response
{
    $this->denyAccessUnlessGranted('ROLE_USER');
    $user = $this->getUser();

    $status = $request->query->get('status');

    $criteria = ['user' => $user];
    if ($status) {
        $criteria['status'] = $status;
    }

    $orders = $em->getRepository(Order::class)->findBy(
        $criteria,
        ['createdAt' => 'DESC']
    );

    return $this->render('order/history.html.twig', [
        'orders' => $orders,
        'currentStatus' => $status
    ]);
}
}
