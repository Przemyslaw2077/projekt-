<?php

namespace App\Controller;

use App\Entity\Order;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminOrderController extends AbstractController
{
    #[Route('/admin/orders', name: 'admin_orders')]
    public function adminList(EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        $orders = $em->getRepository(Order::class)
            ->findBy([], ['createdAt' => 'DESC']);

        return $this->render('admin/orders/admin_list.html.twig', [
            'orders' => $orders
        ]);
    }

    #[Route('/admin/orders/status/{id}/{status}', name: 'admin_orders_status')]
    public function changeStatus(
        Order $order,
        string $status,
        EntityManagerInterface $em
    ): Response {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        $allowedStatuses = ['nowe', 'w_realizacji', 'wyslane'];

        if (!in_array($status, $allowedStatuses)) {
            $this->addFlash('error', 'Nieprawidłowy status zamówienia.');
            return $this->redirectToRoute('admin_orders');
        }

        $order->setStatus($status);
        $em->flush();

        $this->addFlash('success', 'Status zamówienia został zmieniony.');
        return $this->redirectToRoute('admin_orders');
    }
}
