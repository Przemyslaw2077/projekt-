<?php

namespace App\Controller;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class AuthController extends AbstractController
{
public function login(AuthenticationUtils $authUtils): Response
{
    $user = $this->getUser();

    if ($user) {
        if (in_array('ROLE_ADMIN', $user->getRoles())) {
            // Admin → panel admina
            return $this->redirectToRoute('admin_dashboard');
        } else {
            // Zwykły user → moje statystyki
            return $this->redirectToRoute('account_stats');
        }
    }

    return $this->render('auth/login.html.twig', [
        'error' => $authUtils->getLastAuthenticationError(),
        'last_username' => $authUtils->getLastUsername(),
    ]);
}


    public function register(
        Request $request,
        EntityManagerInterface $em,
        UserPasswordHasherInterface $passwordHasher
    ): Response {
        if ($request->isMethod('POST')) {
            $user = new User();
            $user->setEmail($request->request->get('email'));
            $user->setPassword(
                $passwordHasher->hashPassword(
                    $user,
                    $request->request->get('password')
                )
            );

            $em->persist($user);
            $em->flush();

            return $this->redirectToRoute('login');
        }

        return $this->render('auth/register.html.twig');
    }
}
