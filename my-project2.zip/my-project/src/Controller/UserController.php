<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    #[Route('/admin/users', name: 'admin_users')]
    public function index(UserRepository $repo): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        return $this->render('users/admin_list.html.twig', [
            'users' => $repo->findAll()
        ]);
    }

#[Route('/admin/users/role/{id}', name: 'admin_users_role')]
public function changeRole(User $user, EntityManagerInterface $em): Response
{
    $this->denyAccessUnlessGranted('ROLE_ADMIN');

    // NIE zmieniamy swojej roli
    if ($user === $this->getUser()) {
        $this->addFlash('error', 'Nie możesz zmienić własnej roli.');
        return $this->redirectToRoute('admin_users');
    }

    // zmiana roli
    $newRole = $user->isAdmin() ? 'USER' : 'ADMIN';
    $user->setRole($newRole);

    $em->flush();

    $this->addFlash('success', 'Rola użytkownika została zmieniona.');
    return $this->redirectToRoute('admin_users');
}
}
