<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'products')]
class Product
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(name: 'category_id')]
    private ?Category $category = null;

    #[ORM\Column(length: 255)]
    private string $name;

    #[ORM\Column(type: 'text')]
    private string $description;

    #[ORM\Column(type: 'decimal', precision: 10, scale: 2)]
    private string $price; // MUSI być string

    #[ORM\Column]
    private int $stock;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getPrice(): string
    {
        return $this->price;
    }

    public function getPriceFloat(): float
    {
        return (float) $this->price;
    }

    public function getStock(): int
    {
        return $this->stock;
    }

    public function getCategory(): ?Category
    {
        return $this->category;
    }

    public function setStock(int $stock): self
    {
    $this->stock = $stock;
    return $this;
    }

    public function setName(string $name): self
{
    $this->name = $name;
    return $this;
}

public function setDescription(string $description): self
{
    $this->description = $description;
    return $this;
}

public function setPrice(string $price): self
{
    $this->price = $price;
    return $this;
}

public function setCategory(?Category $category): self
{
    $this->category = $category;
    return $this;
}

}
