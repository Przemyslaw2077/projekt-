<?php

namespace App\Controller;

use App\Entity\User;
use App\Entity\Order;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminStatsController extends AbstractController
{
    #[Route('/admin/stats', name: 'admin_stats')]
    public function index(EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        $usersCount = $em->getRepository(User::class)->count([]);
        $ordersCount = $em->getRepository(Order::class)->count([]);

        $ordersNew = $em->getRepository(Order::class)->count([
            'status' => 'nowe'
        ]);

        $ordersInProgress = $em->getRepository(Order::class)->count([
            'status' => 'w_realizacji'
        ]);

        $ordersShipped = $em->getRepository(Order::class)->count([
            'status' => 'wyslane'
        ]);

        return $this->render('admin/stats/admin_stats.html.twig', [
            'usersCount' => $usersCount,
            'ordersCount' => $ordersCount,
            'ordersNew' => $ordersNew,
            'ordersInProgress' => $ordersInProgress,
            'ordersShipped' => $ordersShipped,
        ]);
    }
}
